package com.artem.rickportal.portal;

import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PortalEventHandler {

    @SubscribeEvent
    public void onWorldLoad(WorldEvent.Load event) {
        World world = event.getWorld();
        if (!world.isRemote && world instanceof WorldServer) {
            WorldServer worldServer = (WorldServer) world;
            worldServer.addScheduledTask(() -> PortalManager.restorePortalsForDimension(worldServer));
        }
    }
}

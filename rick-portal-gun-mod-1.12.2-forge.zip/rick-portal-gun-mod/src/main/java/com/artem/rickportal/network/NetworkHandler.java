package com.artem.rickportal.network;

import com.artem.rickportal.RickPortalMod;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {

    public static final SimpleNetworkWrapper INSTANCE = NetworkRegistry.INSTANCE.newSimpleChannel(RickPortalMod.MODID);
    private static int packetId = 0;

    public static void init() {
        INSTANCE.registerMessage(PacketClosePortals.Handler.class, PacketClosePortals.class, packetId++, Side.SERVER);
        INSTANCE.registerMessage(PacketCreateCoordPortal.Handler.class, PacketCreateCoordPortal.class, packetId++, Side.SERVER);
        INSTANCE.registerMessage(PacketPortalStatus.Handler.class, PacketPortalStatus.class, packetId++, Side.CLIENT);
        INSTANCE.registerMessage(PacketPortalFx.Handler.class, PacketPortalFx.class, packetId++, Side.CLIENT);
    }

    public static void sendToAllAround(IMessage message, int dimension, double x, double y, double z, double range) {
        INSTANCE.sendToAllAround(message, new NetworkRegistry.TargetPoint(dimension, x, y, z, range));
    }
}

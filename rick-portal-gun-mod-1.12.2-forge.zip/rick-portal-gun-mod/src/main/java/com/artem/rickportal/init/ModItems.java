package com.artem.rickportal.init;

import com.artem.rickportal.RickPortalMod;
import com.artem.rickportal.item.ItemPortalGun;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = RickPortalMod.MODID)
public class ModItems {

    public static final Item PORTAL_GUN = new ItemPortalGun("portal_gun");

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(PORTAL_GUN);
    }

    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        RickPortalMod.proxy.registerItemRenderer(PORTAL_GUN, 0, "inventory");
    }
}

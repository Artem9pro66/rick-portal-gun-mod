package com.artem.rickportal.portal;

import com.artem.rickportal.RickPortalMod;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.common.util.Constants;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PortalSavedData extends WorldSavedData {

    private static final String DATA_NAME = RickPortalMod.MODID + "_global_portals";

    private final Map<UUID, PortalPair> pairsByOwner = new HashMap<>();

    public PortalSavedData() {
        super(DATA_NAME);
    }

    public PortalSavedData(String name) {
        super(name);
    }

    public static PortalSavedData get(World world) {
        MapStorage storage = world.getMapStorage();
        if (storage == null) {
            return new PortalSavedData();
        }
        PortalSavedData instance = (PortalSavedData) storage.getOrLoadData(PortalSavedData.class, DATA_NAME);
        if (instance == null) {
            instance = new PortalSavedData();
            storage.setData(DATA_NAME, instance);
        }
        return instance;
    }

    @Nullable
    public PortalPair getPair(UUID ownerUuid) {
        return pairsByOwner.get(ownerUuid);
    }

    public PortalPair getOrCreatePair(UUID ownerUuid) {
        PortalPair pair = pairsByOwner.get(ownerUuid);
        if (pair == null) {
            pair = new PortalPair(ownerUuid);
            pairsByOwner.put(ownerUuid, pair);
            markDirty();
        }
        return pair;
    }

    public void putPair(UUID ownerUuid, PortalPair pair) {
        pairsByOwner.put(ownerUuid, pair);
        markDirty();
    }

    public void removePair(UUID ownerUuid) {
        if (pairsByOwner.remove(ownerUuid) != null) {
            markDirty();
        }
    }

    public Collection<PortalPair> getAllPairs() {
        return pairsByOwner.values();
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        pairsByOwner.clear();
        NBTTagList list = nbt.getTagList("PortalPairs", Constants.NBT.TAG_COMPOUND);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound pairTag = list.getCompoundTagAt(i);
            if (pairTag.hasUniqueId("OwnerUUID")) {
                PortalPair pair = PortalPair.readFromNBT(pairTag);
                pairsByOwner.put(pair.getOwnerUuid(), pair);
            }
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        NBTTagList list = new NBTTagList();
        for (PortalPair pair : pairsByOwner.values()) {
            if (pair.hasPrimary() || pair.hasSecondary()) {
                list.appendTag(pair.writeToNBT());
            }
        }
        compound.setTag("PortalPairs", list);
        return compound;
    }
}

package com.artem.rickportal.portal;

import com.artem.rickportal.entity.EntityPortal;
import com.artem.rickportal.init.ModSounds;
import com.artem.rickportal.network.NetworkHandler;
import com.artem.rickportal.network.PacketPortalFx;
import com.artem.rickportal.network.PacketPortalStatus;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

public class PortalManager {

    public static class SurfacePlacement {
        public final BlockPos frontBottomPos;
        public final EnumFacing facing;
        public final double spawnX;
        public final double spawnY;
        public final double spawnZ;

        public SurfacePlacement(BlockPos frontBottomPos, EnumFacing facing, double spawnX, double spawnY, double spawnZ) {
            this.frontBottomPos = frontBottomPos;
            this.facing = facing;
            this.spawnX = spawnX;
            this.spawnY = spawnY;
            this.spawnZ = spawnZ;
        }
    }

    /**
     * Обрабатывает обычный выстрел ПКМ по боковой грани блока:
     * - 1-й выстрел: создаёт первый портал.
     * - 2-й выстрел: создаёт второй портал и связывает пару.
     * - 3-й выстрел (если пара уже существует): закрывает старую пару и открывает новый первый портал.
     */
    public static void handleRightClickShot(World world, EntityPlayerMP player, BlockPos hitBlockPos, EnumFacing sideHit, Vec3d hitVec) {
        if (sideHit == null || !sideHit.getAxis().isHorizontal()) {
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(false, "msg.rickportal.err.vertical_only"), player);
            return;
        }

        SurfacePlacement placement = validateAndResolveSurface(world, hitBlockPos, sideHit, hitVec);
        if (placement == null) {
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(false, "msg.rickportal.err.obstructed"), player);
            return;
        }

        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        PortalSavedData data = PortalSavedData.get(world);
        UUID ownerId = player.getUniqueID();
        PortalPair pair = data.getPair(ownerId);

        // Логика ТРЕТЬЕГО ВЫСТРЕЛА: если уже есть полная пара (2 портала), закрываем её и начинаем новую
        if (pair != null && pair.isCompletePair()) {
            collapseAndRemovePortalInfo(server, pair.getPrimary());
            collapseAndRemovePortalInfo(server, pair.getSecondary());
            data.removePair(ownerId);
            pair = null;
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(true, "msg.rickportal.pair_reset"), player);
        }

        int dimId = world.provider.getDimension();
        String dimName = getDimensionDisplayName(dimId);

        if (pair == null || !pair.hasPrimary()) {
            // Создаём Портал #1
            EntityPortal primaryEntity = spawnPortalEntity(world, ownerId, true, placement);
            PortalInfo primaryInfo = new PortalInfo(
                primaryEntity.getUniqueID(),
                dimId,
                placement.spawnX,
                placement.spawnY,
                placement.spawnZ,
                placement.frontBottomPos,
                placement.facing
            );
            PortalPair newPair = new PortalPair(ownerId);
            newPair.setPrimary(primaryInfo);
            data.putPair(ownerId, newPair);

            NetworkHandler.INSTANCE.sendTo(
                new PacketPortalStatus(
                    true,
                    "msg.rickportal.primary_created",
                    placement.frontBottomPos.getX(),
                    placement.frontBottomPos.getY(),
                    placement.frontBottomPos.getZ(),
                    dimName
                ),
                player
            );
        } else {
            // Создаём Портал #2 и связываем оба портала
            EntityPortal secondaryEntity = spawnPortalEntity(world, ownerId, false, placement);
            PortalInfo secondaryInfo = new PortalInfo(
                secondaryEntity.getUniqueID(),
                dimId,
                placement.spawnX,
                placement.spawnY,
                placement.spawnZ,
                placement.frontBottomPos,
                placement.facing
            );
            pair.setSecondary(secondaryInfo);
            data.putPair(ownerId, pair);

            linkBothPortals(server, pair);

            NetworkHandler.INSTANCE.sendTo(
                new PacketPortalStatus(
                    true,
                    "msg.rickportal.secondary_created",
                    placement.frontBottomPos.getX(),
                    placement.frontBottomPos.getY(),
                    placement.frontBottomPos.getZ(),
                    dimName
                ),
                player
            );
        }
    }

    /**
     * Создаёт второй портал по заданным координатам (X, Y, Z) и измерению из GUI клавиши P.
     */
    public static void createSecondPortalByCoordinates(EntityPlayerMP player, int targetX, int targetY, int targetZ, int targetDim) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        PortalSavedData data = PortalSavedData.get(player.world);
        UUID ownerId = player.getUniqueID();
        PortalPair pair = data.getPair(ownerId);

        // Проверка 1: существует ли первый портал
        if (pair == null || !pair.hasPrimary()) {
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(false, "msg.rickportal.err.no_primary"), player);
            return;
        }

        // Проверка 2: корректность высоты Y
        if (targetY < 1 || targetY > 253) {
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(false, "msg.rickportal.err.invalid_coords"), player);
            return;
        }

        // Проверка 3: существование выбранного измерения (Overworld 0, Nether -1, The End 1)
        if (!DimensionManager.isDimensionRegistered(targetDim)) {
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(false, "msg.rickportal.err.invalid_dim"), player);
            return;
        }

        WorldServer targetWorld = server.getWorld(targetDim);
        if (targetWorld == null) {
            DimensionManager.initDimension(targetDim);
            targetWorld = server.getWorld(targetDim);
        }
        if (targetWorld == null) {
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(false, "msg.rickportal.err.invalid_dim"), player);
            return;
        }

        // Принудительно загружаем целевой чанк, чтобы проверить блоки на любой дальности
        targetWorld.getChunkProvider().provideChunk(targetX >> 4, targetZ >> 4);

        BlockPos targetPos = new BlockPos(targetX, targetY, targetZ);
        SurfacePlacement placement = findValidCoordinateSurface(targetWorld, targetPos);

        String dimName = getDimensionDisplayName(targetDim);
        if (placement == null) {
            NetworkHandler.INSTANCE.sendTo(
                new PacketPortalStatus(false, "msg.rickportal.err.no_surface_at_coords", targetX, targetY, targetZ, dimName),
                player
            );
            return;
        }

        // Если второй портал уже был открыт ранее, аккуратно закрываем старый второй портал
        if (pair.hasSecondary()) {
            collapseAndRemovePortalInfo(server, pair.getSecondary());
        }

        EntityPortal secondaryEntity = spawnPortalEntity(targetWorld, ownerId, false, placement);
        PortalInfo secondaryInfo = new PortalInfo(
            secondaryEntity.getUniqueID(),
            targetDim,
            placement.spawnX,
            placement.spawnY,
            placement.spawnZ,
            placement.frontBottomPos,
            placement.facing
        );
        pair.setSecondary(secondaryInfo);
        data.putPair(ownerId, pair);

        linkBothPortals(server, pair);

        NetworkHandler.INSTANCE.sendTo(
            new PacketPortalStatus(
                true,
                "msg.rickportal.secondary_created",
                placement.frontBottomPos.getX(),
                placement.frontBottomPos.getY(),
                placement.frontBottomPos.getZ(),
                dimName
            ),
            player
        );
    }

    /**
     * Закрывает оба портала игрока при нажатии клавиши K.
     */
    public static void closePlayerPortals(EntityPlayerMP player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        PortalSavedData data = PortalSavedData.get(player.world);
        UUID ownerId = player.getUniqueID();
        PortalPair pair = data.getPair(ownerId);

        if (pair == null || (!pair.hasPrimary() && !pair.hasSecondary())) {
            NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(false, "msg.rickportal.no_active_portals"), player);
            return;
        }

        if (pair.hasPrimary()) {
            collapseAndRemovePortalInfo(server, pair.getPrimary());
        }
        if (pair.hasSecondary()) {
            collapseAndRemovePortalInfo(server, pair.getSecondary());
        }

        data.removePair(ownerId);

        // Звук закрытия также слышен самому игроку
        player.world.playSound(
            null,
            player.posX, player.posY, player.posZ,
            ModSounds.PORTAL_CLOSE,
            SoundCategory.PLAYERS,
            0.9F,
            1.0F
        );

        NetworkHandler.INSTANCE.sendTo(new PacketPortalStatus(true, "msg.rickportal.closed"), player);
    }

    /**
     * Проверяет наличие вертикальной поверхности и свободного объёма 1x2 перед ней при обычном выстреле.
     */
    @Nullable
    public static SurfacePlacement validateAndResolveSurface(World world, BlockPos wallPos, EnumFacing sideHit, @Nullable Vec3d hitVec) {
        if (sideHit == null || !sideHit.getAxis().isHorizontal()) {
            return null;
        }

        BlockPos frontPos = wallPos.offset(sideHit);
        BlockPos candidateBottom = frontPos;

        // Если игрок попал в верхнюю половину проёма 1x2, проверяем также смещение на 1 блок вниз
        if (!isValidPortalSpace(world, candidateBottom, sideHit)) {
            BlockPos lowerCandidate = frontPos.down();
            if (isValidPortalSpace(world, lowerCandidate, sideHit)) {
                candidateBottom = lowerCandidate;
            } else {
                return null;
            }
        } else if (hitVec != null && (hitVec.y - wallPos.getY()) > 0.55D && !isPassableBlock(world, frontPos.up()) && isValidPortalSpace(world, frontPos.down(), sideHit)) {
            candidateBottom = frontPos.down();
        }

        return createPlacement(candidateBottom, sideHit);
    }

    /**
     * Ищет подходящую вертикальную поверхность на указанных координатах (X, Y, Z):
     * 1) Если (X, Y, Z) — это свободная точка перед вертикальной стеной, проверяем 4 направления стены вокруг неё.
     * 2) Если (X, Y, Z) — это сам блок вертикальной стены, проверяем его 4 боковые грани.
     */
    @Nullable
    public static SurfacePlacement findValidCoordinateSurface(World world, BlockPos targetPos) {
        // Вариант 1: targetPos — это воздух перед вертикальной стеной
        if (isPassableBlock(world, targetPos)) {
            for (EnumFacing facing : EnumFacing.HORIZONTALS) {
                if (isValidPortalSpace(world, targetPos, facing)) {
                    return createPlacement(targetPos, facing);
                }
            }
        }
        // Вариант 2: targetPos — это сам блок стены, перед которым нужно открыть портал
        if (isSolidWallBlock(world, targetPos)) {
            for (EnumFacing side : EnumFacing.HORIZONTALS) {
                BlockPos frontBottom = targetPos.offset(side);
                if (isValidPortalSpace(world, frontBottom, side)) {
                    return createPlacement(frontBottom, side);
                }
            }
        }
        return null;
    }

    /**
     * Проверяет, что объём 1x2 перед гранью свободен (не внутри блоков и не в жидкости),
     * а позади него действительно есть вертикальная твёрдая поверхность (не в пустом воздухе).
     */
    public static boolean isValidPortalSpace(World world, BlockPos frontBottom, EnumFacing facing) {
        if (frontBottom.getY() < 1 || frontBottom.getY() > 253) {
            return false;
        }
        BlockPos frontTop = frontBottom.up();
        if (!isPassableBlock(world, frontBottom) || !isPassableBlock(world, frontTop)) {
            return false;
        }

        BlockPos wallBottom = frontBottom.offset(facing.getOpposite());
        BlockPos wallTop = frontTop.offset(facing.getOpposite());

        // Требуется вертикальная стена позади портала (запрещено создавать портал в пустом воздухе)
        boolean bottomSolid = isSolidWallFace(world, wallBottom, facing);
        boolean topSolid = isSolidWallFace(world, wallTop, facing);
        if (!bottomSolid && !topSolid) {
            return false;
        }

        // Проверяем отсутствие пересечения с чужим порталом в этой же точке
        AxisAlignedBB checkBox = new AxisAlignedBB(frontBottom).union(new AxisAlignedBB(frontTop)).shrink(0.1D);
        List<EntityPortal> existing = world.getEntitiesWithinAABB(EntityPortal.class, checkBox);
        for (EntityPortal p : existing) {
            if (!p.isClosing() && !p.isDead) {
                return false;
            }
        }
        return true;
    }

    private static boolean isPassableBlock(World world, BlockPos pos) {
        IBlockState state = world.getBlockState(pos);
        if (state.getMaterial().isLiquid()) {
            return false;
        }
        return world.isAirBlock(pos) || state.getBlock().isReplaceable(world, pos) || state.getCollisionBoundingBox(world, pos) == null;
    }

    private static boolean isSolidWallBlock(World world, BlockPos pos) {
        IBlockState state = world.getBlockState(pos);
        return state.getMaterial().isSolid() && !state.getMaterial().isLiquid();
    }

    private static boolean isSolidWallFace(World world, BlockPos wallPos, EnumFacing facingOutward) {
        IBlockState state = world.getBlockState(wallPos);
        if (!state.getMaterial().isSolid() || state.getMaterial().isLiquid()) {
            return false;
        }
        return state.isSideSolid(world, wallPos, facingOutward) || state.isFullBlock() || state.isFullCube();
    }

    private static SurfacePlacement createPlacement(BlockPos frontBottom, EnumFacing facing) {
        // Смещаем плоскость портала на 0.06 блока от поверхности стены, чтобы избежать Z-fighting
        double cx = frontBottom.getX() + 0.5D - facing.getXOffset() * 0.44D;
        double cy = frontBottom.getY();
        double cz = frontBottom.getZ() + 0.5D - facing.getZOffset() * 0.44D;
        return new SurfacePlacement(frontBottom, facing, cx, cy, cz);
    }

    private static EntityPortal spawnPortalEntity(World world, UUID ownerId, boolean isPrimary, SurfacePlacement placement) {
        EntityPortal portal = new EntityPortal(
            world,
            ownerId,
            isPrimary,
            placement.spawnX,
            placement.spawnY,
            placement.spawnZ,
            placement.facing,
            placement.frontBottomPos
        );
        world.spawnEntity(portal);

        world.playSound(
            null,
            placement.spawnX, placement.spawnY + 1.0D, placement.spawnZ,
            ModSounds.PORTAL_OPEN,
            SoundCategory.BLOCKS,
            1.0F,
            1.0F
        );

        NetworkHandler.sendToAllAround(
            new PacketPortalFx(
                1,
                placement.spawnX, placement.spawnY + 1.0D, placement.spawnZ,
                0, 0, 0,
                placement.facing.getHorizontalIndex()
            ),
            world.provider.getDimension(),
            placement.spawnX, placement.spawnY + 1.0D, placement.spawnZ,
            64.0D
        );

        return portal;
    }

    public static void linkBothPortals(MinecraftServer server, PortalPair pair) {
        PortalInfo p1 = pair.getPrimary();
        PortalInfo p2 = pair.getSecondary();
        if (p1 == null || p2 == null) {
            return;
        }

        EntityPortal e1 = findOrRestorePortalEntity(server, pair.getOwnerUuid(), true, p1);
        EntityPortal e2 = findOrRestorePortalEntity(server, pair.getOwnerUuid(), false, p2);

        if (e1 != null) {
            e1.linkToDestination(p2.getDimension(), p2.getPosX(), p2.getPosY(), p2.getPosZ(), p2.getFacing());
            p1.setEntityUuid(e1.getUniqueID());
        }
        if (e2 != null) {
            e2.linkToDestination(p1.getDimension(), p1.getPosX(), p1.getPosY(), p1.getPosZ(), p1.getFacing());
            p2.setEntityUuid(e2.getUniqueID());
        }
    }

    @Nullable
    public static EntityPortal findOrRestorePortalEntity(MinecraftServer server, UUID ownerUuid, boolean isPrimary, PortalInfo info) {
        if (!DimensionManager.isDimensionRegistered(info.getDimension())) {
            return null;
        }
        WorldServer world = server.getWorld(info.getDimension());
        if (world == null) {
            DimensionManager.initDimension(info.getDimension());
            world = server.getWorld(info.getDimension());
        }
        if (world == null) {
            return null;
        }

        // Подгружаем чанк, где находится портал
        world.getChunkProvider().provideChunk(info.getAnchorPos().getX() >> 4, info.getAnchorPos().getZ() >> 4);

        if (info.getEntityUuid() != null) {
            Entity found = world.getEntityFromUuid(info.getEntityUuid());
            if (found instanceof EntityPortal && !found.isDead && !((EntityPortal) found).isClosing()) {
                return (EntityPortal) found;
            }
        }

        // Поиск по координатам в радиусе 1.5 блока
        AxisAlignedBB box = new AxisAlignedBB(
            info.getPosX() - 1.0D, info.getPosY() - 0.5D, info.getPosZ() - 1.0D,
            info.getPosX() + 1.0D, info.getPosY() + 2.5D, info.getPosZ() + 1.0D
        );
        List<EntityPortal> nearby = world.getEntitiesWithinAABB(EntityPortal.class, box);
        for (EntityPortal candidate : nearby) {
            if (!candidate.isDead && !candidate.isClosing() && ownerUuid.equals(candidate.getOwnerUuid()) && candidate.isPrimary() == isPrimary) {
                info.setEntityUuid(candidate.getUniqueID());
                return candidate;
            }
        }

        // Восстановление портала из WorldSavedData после перезагрузки мира/чанка
        EntityPortal restored = new EntityPortal(
            world,
            ownerUuid,
            isPrimary,
            info.getPosX(),
            info.getPosY(),
            info.getPosZ(),
            info.getFacing(),
            info.getAnchorPos()
        );
        restored.setOpeningTicks(EntityPortal.MAX_OPEN_TICKS);
        world.spawnEntity(restored);
        info.setEntityUuid(restored.getUniqueID());
        return restored;
    }

    private static void collapseAndRemovePortalInfo(MinecraftServer server, @Nullable PortalInfo info) {
        if (info == null || !DimensionManager.isDimensionRegistered(info.getDimension())) {
            return;
        }
        WorldServer world = server.getWorld(info.getDimension());
        if (world == null) {
            return;
        }
        world.getChunkProvider().provideChunk(info.getAnchorPos().getX() >> 4, info.getAnchorPos().getZ() >> 4);

        if (info.getEntityUuid() != null) {
            Entity entity = world.getEntityFromUuid(info.getEntityUuid());
            if (entity instanceof EntityPortal && !entity.isDead) {
                ((EntityPortal) entity).startClosingAnimation();
            }
        }

        AxisAlignedBB box = new AxisAlignedBB(
            info.getPosX() - 1.2D, info.getPosY() - 0.5D, info.getPosZ() - 1.2D,
            info.getPosX() + 1.2D, info.getPosY() + 2.5D, info.getPosZ() + 1.2D
        );
        for (EntityPortal portal : world.getEntitiesWithinAABB(EntityPortal.class, box)) {
            if (!portal.isDead) {
                portal.startClosingAnimation();
            }
        }

        world.playSound(
            null,
            info.getPosX(), info.getPosY() + 1.0D, info.getPosZ(),
            ModSounds.PORTAL_CLOSE,
            SoundCategory.BLOCKS,
            1.0F,
            1.0F
        );

        NetworkHandler.sendToAllAround(
            new PacketPortalFx(
                2,
                info.getPosX(), info.getPosY() + 1.0D, info.getPosZ(),
                0, 0, 0,
                info.getFacing().getHorizontalIndex()
            ),
            info.getDimension(),
            info.getPosX(), info.getPosY() + 1.0D, info.getPosZ(),
            64.0D
        );
    }

    public static void restorePortalsForDimension(WorldServer world) {
        MinecraftServer server = world.getMinecraftServer();
        if (server == null) {
            return;
        }
        int dim = world.provider.getDimension();
        PortalSavedData data = PortalSavedData.get(world);
        for (PortalPair pair : data.getAllPairs()) {
            PortalInfo p1 = pair.getPrimary();
            PortalInfo p2 = pair.getSecondary();
            if (p1 != null && p1.getDimension() == dim) {
                EntityPortal e1 = findOrRestorePortalEntity(server, pair.getOwnerUuid(), true, p1);
                if (e1 != null && p2 != null) {
                    e1.linkToDestination(p2.getDimension(), p2.getPosX(), p2.getPosY(), p2.getPosZ(), p2.getFacing());
                }
            }
            if (p2 != null && p2.getDimension() == dim) {
                EntityPortal e2 = findOrRestorePortalEntity(server, pair.getOwnerUuid(), false, p2);
                if (e2 != null && p1 != null) {
                    e2.linkToDestination(p1.getDimension(), p1.getPosX(), p1.getPosY(), p1.getPosZ(), p1.getFacing());
                }
            }
        }
        data.markDirty();
    }

    public static String getDimensionDisplayName(int dimId) {
        switch (dimId) {
            case 0:
                return "Overworld";
            case -1:
                return "Nether";
            case 1:
                return "The End";
            default:
                return "DIM " + dimId;
        }
    }
}

package com.artem.rickportal.init;

import com.artem.rickportal.RickPortalMod;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = RickPortalMod.MODID)
public class ModSounds {

    public static final SoundEvent PORTAL_SHOOT = createSound("portal_shoot");
    public static final SoundEvent PORTAL_OPEN = createSound("portal_open");
    public static final SoundEvent PORTAL_CLOSE = createSound("portal_close");
    public static final SoundEvent PORTAL_TRAVEL = createSound("portal_travel");

    private static SoundEvent createSound(String name) {
        ResourceLocation loc = new ResourceLocation(RickPortalMod.MODID, name);
        SoundEvent event = new SoundEvent(loc);
        event.setRegistryName(loc);
        return event;
    }

    @SubscribeEvent
    public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
        event.getRegistry().registerAll(
            PORTAL_SHOOT,
            PORTAL_OPEN,
            PORTAL_CLOSE,
            PORTAL_TRAVEL
        );
    }
}

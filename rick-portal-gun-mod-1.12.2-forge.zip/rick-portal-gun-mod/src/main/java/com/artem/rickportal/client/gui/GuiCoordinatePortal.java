package com.artem.rickportal.client.gui;

import com.artem.rickportal.RickPortalMod;
import com.artem.rickportal.network.NetworkHandler;
import com.artem.rickportal.network.PacketCreateCoordPortal;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

@SideOnly(Side.CLIENT)
public class GuiCoordinatePortal extends GuiScreen {

    private static final ResourceLocation GUI_TEXTURE =
        new ResourceLocation(RickPortalMod.MODID, "textures/gui/portal_coords_gui.png");

    private static final int PANEL_WIDTH = 220;
    private static final int PANEL_HEIGHT = 176;

    private static final int BTN_DIMENSION = 1;
    private static final int BTN_CREATE = 2;
    private static final int BTN_CANCEL = 3;

    // Доступные измерения: 0 (Overworld), -1 (Nether), 1 (The End)
    private static final int[] DIMENSIONS = new int[]{0, -1, 1};
    private int selectedDimIndex = 0;

    private GuiTextField fieldX;
    private GuiTextField fieldY;
    private GuiTextField fieldZ;

    private GuiButton btnDimension;
    private GuiButton btnCreate;
    private GuiButton btnCancel;

    private int guiLeft;
    private int guiTop;
    private String errorMessage = "";

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        this.buttonList.clear();

        this.guiLeft = (this.width - PANEL_WIDTH) / 2;
        this.guiTop = (this.height - PANEL_HEIGHT) / 2;

        int defaultX = mc.player != null ? (int) Math.floor(mc.player.posX) : 0;
        int defaultY = mc.player != null ? (int) Math.floor(mc.player.posY) : 64;
        int defaultZ = mc.player != null ? (int) Math.floor(mc.player.posZ) : 0;

        if (mc.player != null) {
            int playerDim = mc.player.world.provider.getDimension();
            for (int i = 0; i < DIMENSIONS.length; i++) {
                if (DIMENSIONS[i] == playerDim) {
                    selectedDimIndex = i;
                    break;
                }
            }
        }

        String prevX = fieldX != null ? fieldX.getText() : String.valueOf(defaultX);
        String prevY = fieldY != null ? fieldY.getText() : String.valueOf(defaultY);
        String prevZ = fieldZ != null ? fieldZ.getText() : String.valueOf(defaultZ);

        this.fieldX = new GuiTextField(10, this.fontRenderer, guiLeft + 92, guiTop + 34, 112, 18);
        this.fieldX.setMaxStringLength(12);
        this.fieldX.setText(prevX);
        this.fieldX.setFocused(true);

        this.fieldY = new GuiTextField(11, this.fontRenderer, guiLeft + 92, guiTop + 58, 112, 18);
        this.fieldY.setMaxStringLength(6);
        this.fieldY.setText(prevY);

        this.fieldZ = new GuiTextField(12, this.fontRenderer, guiLeft + 92, guiTop + 82, 112, 18);
        this.fieldZ.setMaxStringLength(12);
        this.fieldZ.setText(prevZ);

        this.btnDimension = new GuiButton(
            BTN_DIMENSION,
            guiLeft + 92, guiTop + 106,
            114, 20,
            getDimensionButtonLabel()
        );

        this.btnCreate = new GuiButton(
            BTN_CREATE,
            guiLeft + 14, guiTop + 138,
            94, 20,
            I18n.format("gui.rickportal.create")
        );

        this.btnCancel = new GuiButton(
            BTN_CANCEL,
            guiLeft + 112, guiTop + 138,
            94, 20,
            I18n.format("gui.rickportal.cancel")
        );

        this.buttonList.add(this.btnDimension);
        this.buttonList.add(this.btnCreate);
        this.buttonList.add(this.btnCancel);
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void updateScreen() {
        this.fieldX.updateCursorCounter();
        this.fieldY.updateCursorCounter();
        this.fieldZ.updateCursorCounter();
    }

    private String getDimensionButtonLabel() {
        int dim = DIMENSIONS[selectedDimIndex];
        switch (dim) {
            case 0:
                return I18n.format("gui.rickportal.dim.overworld");
            case -1:
                return I18n.format("gui.rickportal.dim.nether");
            case 1:
                return I18n.format("gui.rickportal.dim.end");
            default:
                return "DIM " + dim;
        }
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (!button.enabled) {
            return;
        }
        if (button.id == BTN_DIMENSION) {
            selectedDimIndex = (selectedDimIndex + 1) % DIMENSIONS.length;
            this.btnDimension.displayString = getDimensionButtonLabel();
            this.errorMessage = "";
        } else if (button.id == BTN_CANCEL) {
            this.mc.displayGuiScreen(null);
        } else if (button.id == BTN_CREATE) {
            submitCoordinates();
        }
    }

    private void submitCoordinates() {
        String sx = this.fieldX.getText().trim();
        String sy = this.fieldY.getText().trim();
        String sz = this.fieldZ.getText().trim();

        try {
            int x = Integer.parseInt(sx);
            int y = Integer.parseInt(sy);
            int z = Integer.parseInt(sz);

            if (y < 1 || y > 253) {
                this.errorMessage = I18n.format("msg.rickportal.err.invalid_coords");
                return;
            }

            int dimId = DIMENSIONS[selectedDimIndex];
            this.errorMessage = "";
            NetworkHandler.INSTANCE.sendToServer(new PacketCreateCoordPortal(x, y, z, dimId));
        } catch (NumberFormatException ex) {
            this.errorMessage = I18n.format("msg.rickportal.err.invalid_coords");
        }
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage != null ? errorMessage : "";
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            this.mc.displayGuiScreen(null);
            return;
        }
        if (keyCode == Keyboard.KEY_TAB) {
            if (fieldX.isFocused()) {
                fieldX.setFocused(false);
                fieldY.setFocused(true);
            } else if (fieldY.isFocused()) {
                fieldY.setFocused(false);
                fieldZ.setFocused(true);
            } else {
                fieldZ.setFocused(false);
                fieldX.setFocused(true);
            }
            return;
        }
        if (keyCode == Keyboard.KEY_RETURN || keyCode == Keyboard.KEY_NUMPADENTER) {
            submitCoordinates();
            return;
        }

        // Разрешаем цифры, знак минуса (отрицательные координаты), Backspace, Delete и стрелки
        if (isAllowedCoordChar(typedChar, keyCode)) {
            this.fieldX.textboxKeyTyped(typedChar, keyCode);
            this.fieldY.textboxKeyTyped(typedChar, keyCode);
            this.fieldZ.textboxKeyTyped(typedChar, keyCode);
            this.errorMessage = "";
        }
    }

    private boolean isAllowedCoordChar(char c, int keyCode) {
        if (Character.isDigit(c) || c == '-') {
            return true;
        }
        return keyCode == Keyboard.KEY_BACK
            || keyCode == Keyboard.KEY_DELETE
            || keyCode == Keyboard.KEY_LEFT
            || keyCode == Keyboard.KEY_RIGHT
            || keyCode == Keyboard.KEY_HOME
            || keyCode == Keyboard.KEY_END
            || GuiScreen.isKeyComboCtrlA(keyCode)
            || GuiScreen.isKeyComboCtrlC(keyCode)
            || GuiScreen.isKeyComboCtrlV(keyCode)
            || GuiScreen.isKeyComboCtrlX(keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        this.fieldX.mouseClicked(mouseX, mouseY, mouseButton);
        this.fieldY.mouseClicked(mouseX, mouseY, mouseButton);
        this.fieldZ.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();

        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        this.mc.getTextureManager().bindTexture(GUI_TEXTURE);
        this.drawTexturedModalRect(guiLeft, guiTop, 0, 0, PANEL_WIDTH, PANEL_HEIGHT);

        String title = I18n.format("gui.rickportal.title");
        this.drawCenteredString(this.fontRenderer, title, guiLeft + PANEL_WIDTH / 2, guiTop + 10, 0x55FF55);

        this.fontRenderer.drawStringWithShadow(I18n.format("gui.rickportal.x"), guiLeft + 16, guiTop + 39, 0xE0E0E0);
        this.fontRenderer.drawStringWithShadow(I18n.format("gui.rickportal.y"), guiLeft + 16, guiTop + 63, 0xE0E0E0);
        this.fontRenderer.drawStringWithShadow(I18n.format("gui.rickportal.z"), guiLeft + 16, guiTop + 87, 0xE0E0E0);
        this.fontRenderer.drawStringWithShadow(I18n.format("gui.rickportal.dimension"), guiLeft + 16, guiTop + 112, 0xE0E0E0);

        this.fieldX.drawTextBox();
        this.fieldY.drawTextBox();
        this.fieldZ.drawTextBox();

        super.drawScreen(mouseX, mouseY, partialTicks);

        if (this.errorMessage != null && !this.errorMessage.isEmpty()) {
            this.fontRenderer.drawSplitString(this.errorMessage, guiLeft + 10, guiTop + PANEL_HEIGHT + 6, PANEL_WIDTH - 20, 0xFF5555);
        } else {
            String hint = I18n.format("gui.rickportal.hint");
            this.drawCenteredString(this.fontRenderer, hint, guiLeft + PANEL_WIDTH / 2, guiTop + PANEL_HEIGHT + 6, 0x88FF88);
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}

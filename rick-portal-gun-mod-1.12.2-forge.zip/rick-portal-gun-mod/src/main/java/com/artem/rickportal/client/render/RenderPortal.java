package com.artem.rickportal.client.render;

import com.artem.rickportal.RickPortalMod;
import com.artem.rickportal.entity.EntityPortal;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

import javax.annotation.Nullable;

@SideOnly(Side.CLIENT)
public class RenderPortal extends Render<EntityPortal> {

    private static final ResourceLocation VORTEX_TEXTURE =
        new ResourceLocation(RickPortalMod.MODID, "textures/entity/portal_vortex.png");

    public RenderPortal(RenderManager renderManager) {
        super(renderManager);
        this.shadowSize = 0.0F;
    }

    @Override
    public void doRender(EntityPortal entity, double x, double y, double z, float entityYaw, float partialTicks) {
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y + 1.0F, (float) z);

        EnumFacing facing = entity.getPortalFacing();
        GlStateManager.rotate(-facing.getHorizontalAngle(), 0.0F, 1.0F, 0.0F);

        // Расчёт масштаба для плавной анимации открытия и схлопывания (закрытия)
        float scale = 1.0F;
        int closeTicks = entity.getClosingTicks();
        int openTicks = entity.getOpeningTicks();
        if (closeTicks > 0) {
            float progress = ((float) closeTicks + partialTicks) / (float) EntityPortal.MAX_CLOSE_TICKS;
            scale = Math.max(0.02F, 1.0F - progress);
        } else if (openTicks < EntityPortal.MAX_OPEN_TICKS) {
            float progress = ((float) openTicks + partialTicks) / (float) EntityPortal.MAX_OPEN_TICKS;
            scale = Math.min(1.0F, 0.1F + 0.9F * progress);
        }

        // Овал портала ~1x2 блока (ширина 1.0, высота 2.0)
        GlStateManager.scale(0.52F * scale, 1.02F * scale, 1.0F);

        this.bindEntityTexture(entity);

        GlStateManager.disableLighting();
        // Двусторонний рендеринг (портал виден и работает с обеих сторон)
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);

        // Максимальное свечение в темноте (Fullbright)
        float lastBrightnessX = OpenGlHelper.lastBrightnessX;
        float lastBrightnessY = OpenGlHelper.lastBrightnessY;
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);

        float time = (entity.ticksExisted + partialTicks) * 0.085F;

        // 1. Основной вращающийся зелёный вихрь
        renderSpinningDisc(time, 0.0F, 1.0F, 0.96F, 1.0F, 1.0F, 1.0F);

        // 2. Второй встречно-вращающийся внутренний слой плазмы для эффекта глубокого вихря Рика и Морти
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        renderSpinningDisc(-time * 1.4F, 0.004F, 0.88F, 0.65F, 0.65F, 1.0F, 0.45F);
        renderSpinningDisc(-time * 1.4F, -0.004F, 0.88F, 0.65F, 0.65F, 1.0F, 0.45F);

        // 3. Светящееся неоново-зелёное кольцо по краям портала
        renderGlowingEdgeRing(time, entity.isLinked());

        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, lastBrightnessX, lastBrightnessY);
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableBlend();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }

    private void renderSpinningDisc(float angleRad, float zOffset, float radiusScale, float alpha, float rCol, float gCol, float bCol) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        int segments = 32;

        float cosA = (float) Math.cos(angleRad);
        float sinA = (float) Math.sin(angleRad);

        buffer.begin(GL11.GL_TRIANGLE_FAN, DefaultVertexFormats.POSITION_TEX_COLOR);
        buffer.pos(0.0D, 0.0D, zOffset).tex(0.5D, 0.5D).color(rCol, gCol, bCol, alpha).endVertex();

        for (int i = 0; i <= segments; i++) {
            double theta = (Math.PI * 2.0D * i) / segments;
            float vx = (float) Math.cos(theta) * radiusScale;
            float vy = (float) Math.sin(theta) * radiusScale;

            float ux = (float) Math.cos(theta) * 0.48F;
            float uy = (float) Math.sin(theta) * 0.48F;
            float rotU = 0.5F + (ux * cosA - uy * sinA);
            float rotV = 0.5F + (ux * sinA + uy * cosA);

            buffer.pos(vx, vy, zOffset).tex(rotU, rotV).color(rCol, gCol, bCol, alpha).endVertex();
        }
        tessellator.draw();
    }

    private void renderGlowingEdgeRing(float time, boolean isLinked) {
        GlStateManager.disableTexture2D();
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        int segments = 36;
        float innerR = 0.90F;
        float outerR = 1.03F;

        float pulse = 0.85F + 0.15F * (float) Math.sin(time * 3.0F);
        float r = isLinked ? 0.45F * pulse : 0.25F * pulse;
        float g = 1.0F;
        float b = isLinked ? 0.25F * pulse : 0.15F;

        buffer.begin(GL11.GL_TRIANGLE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segments; i++) {
            double theta = (Math.PI * 2.0D * i) / segments;
            double cos = Math.cos(theta);
            double sin = Math.sin(theta);
            buffer.pos(cos * innerR, sin * innerR, 0.0D).color(r, g, b, 0.85F).endVertex();
            buffer.pos(cos * outerR, sin * outerR, 0.0D).color(r, g, b, 0.0F).endVertex();
        }
        tessellator.draw();
        GlStateManager.enableTexture2D();
    }

    @Nullable
    @Override
    protected ResourceLocation getEntityTexture(EntityPortal entity) {
        return VORTEX_TEXTURE;
    }
}

package com.artem.rickportal.proxy;

import com.artem.rickportal.RickPortalMod;
import com.artem.rickportal.client.KeyHandler;
import com.artem.rickportal.client.ParticleHelper;
import com.artem.rickportal.client.gui.GuiCoordinatePortal;
import com.artem.rickportal.client.render.PortalGunBakedModel;
import com.artem.rickportal.client.render.RenderPortal;
import com.artem.rickportal.entity.EntityPortal;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ModelBakery;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.ModelBakeEvent;
import net.minecraftforge.client.model.IModel;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.model.ModelLoaderRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.model.TRSRTransformation;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClientProxy extends CommonProxy {

    public static final ModelResourceLocation MODEL_HAND =
        new ModelResourceLocation(new ResourceLocation(RickPortalMod.MODID, "portal_gun"), "inventory");
    public static final ModelResourceLocation MODEL_INVENTORY =
        new ModelResourceLocation(new ResourceLocation(RickPortalMod.MODID, "portal_gun_inventory"), "inventory");

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
        RenderingRegistry.registerEntityRenderingHandler(EntityPortal.class, RenderPortal::new);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void init(FMLInitializationEvent event) {
        super.init(event);
        KeyHandler.init();
        MinecraftForge.EVENT_BUS.register(new KeyHandler());
    }

    @Override
    public void postInit(FMLPostInitializationEvent event) {
        super.postInit(event);
    }

    @Override
    public void registerItemRenderer(Item item, int meta, String id) {
        ModelBakery.registerItemVariants(
            item,
            new ResourceLocation(RickPortalMod.MODID, "portal_gun"),
            new ResourceLocation(RickPortalMod.MODID, "portal_gun_inventory")
        );
        ModelLoader.setCustomModelResourceLocation(item, meta, MODEL_HAND);
    }

    @Override
    public void scheduleClientTask(Runnable task) {
        Minecraft.getMinecraft().addScheduledTask(task);
    }

    @SubscribeEvent
    public void onModelBake(ModelBakeEvent event) {
        IBakedModel handModel = event.getModelRegistry().getObject(MODEL_HAND);
        if (handModel != null) {
            IBakedModel invModel = handModel;
            try {
                IModel rawInv = ModelLoaderRegistry.getModel(new ResourceLocation(RickPortalMod.MODID, "item/portal_gun_inventory"));
                invModel = rawInv.bake(
                    TRSRTransformation.identity(),
                    net.minecraft.client.renderer.vertex.DefaultVertexFormats.ITEM,
                    ModelLoader.defaultTextureGetter()
                );
            } catch (Exception e) {
                RickPortalMod.LOGGER.warn("Fallback to main 3D model for inventory slot: {}", e.getMessage());
            }
            event.getModelRegistry().putObject(MODEL_HAND, new PortalGunBakedModel(handModel, invModel));
        }
    }

    @Override
    public void handlePortalStatus(boolean success, String messageKey, Object... args) {
        Minecraft mc = Minecraft.getMinecraft();
        String formatted = I18n.format(messageKey, args);
        GuiScreen current = mc.currentScreen;
        if (current instanceof GuiCoordinatePortal) {
            GuiCoordinatePortal coordGui = (GuiCoordinatePortal) current;
            if (success) {
                mc.displayGuiScreen(null);
                if (mc.player != null) {
                    mc.player.sendStatusMessage(new TextComponentString(TextFormatting.GREEN + formatted), true);
                }
            } else {
                coordGui.setErrorMessage(formatted);
            }
        } else if (mc.player != null) {
            TextFormatting color = success ? TextFormatting.GREEN : TextFormatting.RED;
            mc.player.sendStatusMessage(new TextComponentString(color + formatted), true);
        }
    }

    @Override
    public void spawnPortalFx(int fxType, double x, double y, double z, double tx, double ty, double tz, int facingIndex) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null) {
            return;
        }
        EnumFacing facing = EnumFacing.byHorizontalIndex(Math.max(0, facingIndex));
        switch (fxType) {
            case 0: // Beam + muzzle flash from gun to target
                ParticleHelper.spawnShotBeam(mc.world, x, y, z, tx, ty, tz);
                break;
            case 1: // Portal opening burst
                ParticleHelper.spawnPortalOpenBurst(mc.world, x, y, z, facing);
                break;
            case 2: // Portal closing implosion
                ParticleHelper.spawnPortalCloseCollapse(mc.world, x, y, z, facing);
                break;
            case 3: // Entity teleport splash
                ParticleHelper.spawnTeleportSplash(mc.world, x, y, z);
                break;
            case 4: // Portal closing tick particles
                ParticleHelper.spawnPortalClosingTick(mc.world, x, y, z, facing);
                break;
            case 5: // Portal ambient rim particles
                ParticleHelper.spawnPortalAmbientRim(mc.world, x, y, z, facing, tx > 0.5D);
                break;
            default:
                break;
        }
    }
}

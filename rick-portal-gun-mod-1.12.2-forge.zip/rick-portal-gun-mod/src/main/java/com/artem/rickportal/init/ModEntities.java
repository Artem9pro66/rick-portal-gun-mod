package com.artem.rickportal.init;

import com.artem.rickportal.RickPortalMod;
import com.artem.rickportal.entity.EntityPortal;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

public class ModEntities {

    public static void init() {
        EntityRegistry.registerModEntity(
            new ResourceLocation(RickPortalMod.MODID, "rick_portal"),
            EntityPortal.class,
            "rickportal_portal",
            1,
            RickPortalMod.instance,
            128,
            1,
            false
        );
    }
}

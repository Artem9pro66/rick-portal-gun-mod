package com.artem.rickportal.network;

import com.artem.rickportal.RickPortalMod;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketPortalStatus implements IMessage {

    private boolean success;
    private String messageKey;
    private String[] args;

    public PacketPortalStatus() {
    }

    public PacketPortalStatus(boolean success, String messageKey, Object... rawArgs) {
        this.success = success;
        this.messageKey = messageKey != null ? messageKey : "";
        if (rawArgs != null && rawArgs.length > 0) {
            this.args = new String[rawArgs.length];
            for (int i = 0; i < rawArgs.length; i++) {
                this.args[i] = String.valueOf(rawArgs[i]);
            }
        } else {
            this.args = new String[0];
        }
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        this.success = buf.readBoolean();
        this.messageKey = ByteBufUtils.readUTF8String(buf);
        int count = buf.readByte();
        this.args = new String[count];
        for (int i = 0; i < count; i++) {
            this.args[i] = ByteBufUtils.readUTF8String(buf);
        }
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeBoolean(this.success);
        ByteBufUtils.writeUTF8String(buf, this.messageKey);
        int count = this.args != null ? Math.min(this.args.length, 16) : 0;
        buf.writeByte(count);
        for (int i = 0; i < count; i++) {
            ByteBufUtils.writeUTF8String(buf, this.args[i]);
        }
    }

    public static class Handler implements IMessageHandler<PacketPortalStatus, IMessage> {
        @Override
        public IMessage onMessage(PacketPortalStatus message, MessageContext ctx) {
            RickPortalMod.proxy.scheduleClientTask(() ->
                RickPortalMod.proxy.handlePortalStatus(message.success, message.messageKey, (Object[]) message.args)
            );
            return null;
        }
    }
}

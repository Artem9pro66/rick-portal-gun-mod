package com.artem.rickportal.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ParticleHelper {

    /**
     * Создаёт зелёную вспышку у ствола пушки и луч из зелёных энергетических частиц до точки попадания.
     */
    public static void spawnShotBeam(World world, double sx, double sy, double sz, double tx, double ty, double tz) {
        Vec3d start = new Vec3d(sx, sy, sz);
        Vec3d end = new Vec3d(tx, ty, tz);
        double dist = start.distanceTo(end);
        int steps = Math.min(80, Math.max(8, (int) (dist * 3.5D)));

        // Зелёная вспышка у дула пушки
        for (int i = 0; i < 10; i++) {
            double ox = (world.rand.nextDouble() - 0.5D) * 0.2D;
            double oy = (world.rand.nextDouble() - 0.5D) * 0.2D;
            double oz = (world.rand.nextDouble() - 0.5D) * 0.2D;
            spawnGreenEnergyParticle(world, sx + ox, sy + oy, sz + oz, ox * 0.3D, oy * 0.3D, oz * 0.3D, 1.3F);
        }

        // Луч энергии
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / (double) steps;
            double px = sx + (tx - sx) * t;
            double py = sy + (ty - sy) * t;
            double pz = sz + (tz - sz) * t;
            spawnGreenEnergyParticle(world, px, py, pz, 0.0D, 0.01D, 0.0D, 1.0F);
        }
    }

    /**
     * Эффект открытия портала: кольцо разлетающихся ярко-зелёных частиц.
     */
    public static void spawnPortalOpenBurst(World world, double cx, double cy, double cz, EnumFacing facing) {
        for (int i = 0; i < 36; i++) {
            double angle = (Math.PI * 2.0D * i) / 36.0D;
            double rx = Math.cos(angle) * 0.48D;
            double ry = Math.sin(angle) * 0.95D;
            double px = cx + (facing.getAxis() == EnumFacing.Axis.Z ? rx : 0.0D);
            double py = cy + ry;
            double pz = cz + (facing.getAxis() == EnumFacing.Axis.X ? rx : 0.0D);
            double vx = facing.getXOffset() * 0.08D + (world.rand.nextDouble() - 0.5D) * 0.06D;
            double vy = (world.rand.nextDouble() - 0.5D) * 0.08D;
            double vz = facing.getZOffset() * 0.08D + (world.rand.nextDouble() - 0.5D) * 0.06D;
            spawnGreenEnergyParticle(world, px, py, pz, vx, vy, vz, 1.5F);
            world.spawnParticle(EnumParticleTypes.VILLAGER_HAPPY, px, py, pz, vx, vy, vz);
        }
    }

    /**
     * Эффект закрытия (схлопывания) портала к центру.
     */
    public static void spawnPortalCloseCollapse(World world, double cx, double cy, double cz, EnumFacing facing) {
        for (int i = 0; i < 32; i++) {
            double angle = world.rand.nextDouble() * Math.PI * 2.0D;
            double rx = Math.cos(angle) * 0.55D;
            double ry = Math.sin(angle) * 1.0D;
            double px = cx + (facing.getAxis() == EnumFacing.Axis.Z ? rx : 0.0D);
            double py = cy + ry;
            double pz = cz + (facing.getAxis() == EnumFacing.Axis.X ? rx : 0.0D);
            double vx = (cx - px) * 0.22D;
            double vy = (cy - py) * 0.22D;
            double vz = (cz - pz) * 0.22D;
            spawnGreenEnergyParticle(world, px, py, pz, vx, vy, vz, 1.4F);
        }
    }

    public static void spawnPortalClosingTick(World world, double cx, double cy, double cz, EnumFacing facing) {
        for (int i = 0; i < 6; i++) {
            double angle = world.rand.nextDouble() * Math.PI * 2.0D;
            double rx = Math.cos(angle) * 0.35D;
            double ry = Math.sin(angle) * 0.7D;
            double px = cx + (facing.getAxis() == EnumFacing.Axis.Z ? rx : 0.0D);
            double py = cy + ry;
            double pz = cz + (facing.getAxis() == EnumFacing.Axis.X ? rx : 0.0D);
            spawnGreenEnergyParticle(world, px, py, pz, (cx - px) * 0.2D, (cy - py) * 0.2D, (cz - pz) * 0.2D, 1.1F);
        }
    }

    /**
     * Фоновые частицы по светящимся краям активного портала.
     */
    public static void spawnPortalAmbientRim(World world, double x, double y, double z, EnumFacing facing, boolean linked) {
        if (world.rand.nextInt(2) != 0) {
            return;
        }
        double angle = world.rand.nextDouble() * Math.PI * 2.0D;
        double rx = Math.cos(angle) * 0.47D;
        double ry = Math.sin(angle) * 0.94D;
        double cy = y + 1.0D;
        double px = x + (facing.getAxis() == EnumFacing.Axis.Z ? rx : 0.0D);
        double py = cy + ry;
        double pz = z + (facing.getAxis() == EnumFacing.Axis.X ? rx : 0.0D);
        float scale = linked ? 1.15F : 0.85F;
        spawnGreenEnergyParticle(world, px, py, pz, 0.0D, 0.015D, 0.0D, scale);
    }

    /**
     * Вспышка частиц при телепортации игрока или моба.
     */
    public static void spawnTeleportSplash(World world, double cx, double cy, double cz) {
        for (int i = 0; i < 24; i++) {
            double ox = (world.rand.nextDouble() - 0.5D) * 0.8D;
            double oy = (world.rand.nextDouble() - 0.5D) * 1.6D;
            double oz = (world.rand.nextDouble() - 0.5D) * 0.8D;
            spawnGreenEnergyParticle(world, cx + ox, cy + oy, cz + oz, ox * 0.15D, 0.05D, oz * 0.15D, 1.4F);
        }
    }

    private static void spawnGreenEnergyParticle(World world, double x, double y, double z, double vx, double vy, double vz, float scale) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.effectRenderer == null) {
            return;
        }
        // Используем REDSTONE частицу с заданием ярко-зелёного/лаймового цвета Рика (#39FF14 -> R=0.22, G=1.0, B=0.08)
        Particle p = mc.effectRenderer.spawnEffectParticle(
            EnumParticleTypes.REDSTONE.getParticleID(),
            x, y, z,
            0.0D, 0.0D, 0.0D
        );
        if (p != null) {
            float greenTint = 0.85F + world.rand.nextFloat() * 0.15F;
            float redTint = 0.18F + world.rand.nextFloat() * 0.25F;
            p.setRBGColorF(redTint, greenTint, 0.10F);
            p.multipleParticleScaleBy(scale);
            p.motionX = vx;
            p.motionY = vy;
            p.motionZ = vz;
        }
    }
}

package com.artem.rickportal;

import com.artem.rickportal.init.ModEntities;
import com.artem.rickportal.init.ModItems;
import com.artem.rickportal.network.NetworkHandler;
import com.artem.rickportal.portal.PortalEventHandler;
import com.artem.rickportal.proxy.CommonProxy;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(
    modid = RickPortalMod.MODID,
    name = RickPortalMod.NAME,
    version = RickPortalMod.VERSION,
    acceptedMinecraftVersions = "[1.12.2]"
)
public class RickPortalMod {

    public static final String MODID = "rickportal";
    public static final String NAME = "Rick Portal Gun Mod";
    public static final String VERSION = "1.0.0";

    public static final Logger LOGGER = LogManager.getLogger(MODID);

    @Mod.Instance(MODID)
    public static RickPortalMod instance;

    @SidedProxy(
        clientSide = "com.artem.rickportal.proxy.ClientProxy",
        serverSide = "com.artem.rickportal.proxy.CommonProxy"
    )
    public static CommonProxy proxy;

    public static final CreativeTabs CREATIVE_TAB = new CreativeTabs("rickportal") {
        @Override
        public ItemStack createIcon() {
            return new ItemStack(ModItems.PORTAL_GUN);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        NetworkHandler.init();
        ModEntities.init();
        MinecraftForge.EVENT_BUS.register(new PortalEventHandler());
        proxy.preInit(event);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        proxy.postInit(event);
    }
}

package com.artem.rickportal.client;

import com.artem.rickportal.client.gui.GuiCoordinatePortal;
import com.artem.rickportal.init.ModItems;
import com.artem.rickportal.network.NetworkHandler;
import com.artem.rickportal.network.PacketClosePortals;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public class KeyHandler {

    // Клавиша K: «Закрыть порталы Рика»
    public static KeyBinding KEY_CLOSE_PORTALS;

    // Клавиша P: «Координаты портала Рика»
    public static KeyBinding KEY_COORD_PORTAL;

    public static void init() {
        KEY_CLOSE_PORTALS = new KeyBinding(
            "key.rickportal.close_portals",
            Keyboard.KEY_K,
            "key.categories.rickportal"
        );
        KEY_COORD_PORTAL = new KeyBinding(
            "key.rickportal.coord_portal",
            Keyboard.KEY_P,
            "key.categories.rickportal"
        );

        ClientRegistry.registerKeyBinding(KEY_CLOSE_PORTALS);
        ClientRegistry.registerKeyBinding(KEY_COORD_PORTAL);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.currentScreen != null) {
            return;
        }

        if (KEY_CLOSE_PORTALS.isPressed()) {
            NetworkHandler.INSTANCE.sendToServer(new PacketClosePortals());
        } else if (KEY_COORD_PORTAL.isPressed()) {
            EntityPlayer player = mc.player;
            boolean holdingGun =
                (!player.getHeldItemMainhand().isEmpty() && player.getHeldItemMainhand().getItem() == ModItems.PORTAL_GUN) ||
                (!player.getHeldItemOffhand().isEmpty() && player.getHeldItemOffhand().getItem() == ModItems.PORTAL_GUN);

            if (!holdingGun) {
                player.sendStatusMessage(
                    new TextComponentString(TextFormatting.RED + I18n.format("msg.rickportal.err.hold_gun")),
                    true
                );
                return;
            }
            mc.displayGuiScreen(new GuiCoordinatePortal());
        }
    }
}

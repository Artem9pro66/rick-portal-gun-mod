package com.artem.rickportal.entity;

import com.artem.rickportal.RickPortalMod;
import com.artem.rickportal.portal.PortalTeleporter;
import com.google.common.base.Optional;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

public class EntityPortal extends Entity {

    private static final DataParameter<Optional<UUID>> OWNER_UUID =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.OPTIONAL_UNIQUE_ID);
    private static final DataParameter<Boolean> IS_PRIMARY =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> FACING_INDEX =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> LINKED =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> TARGET_DIM =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.VARINT);
    private static final DataParameter<Float> TARGET_X =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> TARGET_Y =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> TARGET_Z =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.FLOAT);
    private static final DataParameter<Integer> TARGET_FACING =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> OPENING_TICKS =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> CLOSING_TICKS =
        EntityDataManager.createKey(EntityPortal.class, DataSerializers.VARINT);

    public static final int MAX_OPEN_TICKS = 10;
    public static final int MAX_CLOSE_TICKS = 8;

    private BlockPos anchorPos = BlockPos.ORIGIN;

    public EntityPortal(World worldIn) {
        super(worldIn);
        this.setSize(1.0F, 2.0F);
        this.noClip = true;
        this.isImmuneToFire = true;
        this.ignoreFrustumCheck = true;
    }

    public EntityPortal(World worldIn, UUID ownerUuid, boolean isPrimary, double x, double y, double z, EnumFacing facing, BlockPos anchorPos) {
        this(worldIn);
        this.setOwnerUuid(ownerUuid);
        this.setPrimary(isPrimary);
        this.setPortalFacing(facing);
        this.anchorPos = anchorPos != null ? anchorPos : new BlockPos(x, y, z);
        this.setPosition(x, y, z);
        this.recalculatePortalBoundingBox();
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(OWNER_UUID, Optional.absent());
        this.dataManager.register(IS_PRIMARY, Boolean.TRUE);
        this.dataManager.register(FACING_INDEX, EnumFacing.NORTH.getHorizontalIndex());
        this.dataManager.register(LINKED, Boolean.FALSE);
        this.dataManager.register(TARGET_DIM, 0);
        this.dataManager.register(TARGET_X, 0.0F);
        this.dataManager.register(TARGET_Y, 64.0F);
        this.dataManager.register(TARGET_Z, 0.0F);
        this.dataManager.register(TARGET_FACING, EnumFacing.SOUTH.getHorizontalIndex());
        this.dataManager.register(OPENING_TICKS, 0);
        this.dataManager.register(CLOSING_TICKS, 0);
    }

    @Override
    public void setPosition(double x, double y, double z) {
        this.posX = x;
        this.posY = y;
        this.posZ = z;
        if (this.dataManager != null) {
            this.recalculatePortalBoundingBox();
        } else {
            super.setPosition(x, y, z);
        }
    }

    /**
     * Формирует двусторонний хитбокс 1x2 блока, тонкий по нормали портала,
     * чтобы входить в портал можно было с обеих сторон плоскости.
     */
    public void recalculatePortalBoundingBox() {
        if (this.isClosing()) {
            this.setEntityBoundingBox(new AxisAlignedBB(posX, posY, posZ, posX, posY, posZ));
            return;
        }
        EnumFacing facing = getPortalFacing();
        double halfWidth = 0.5D;
        double halfThick = 0.18D;
        double height = 2.0D;

        if (facing.getAxis() == EnumFacing.Axis.Z) {
            // Портал ориентирован вдоль оси X (смотрит на NORTH или SOUTH)
            this.setEntityBoundingBox(new AxisAlignedBB(
                posX - halfWidth, posY, posZ - halfThick,
                posX + halfWidth, posY + height, posZ + halfThick
            ));
        } else {
            // Портал ориентирован вдоль оси Z (смотрит на EAST или WEST)
            this.setEntityBoundingBox(new AxisAlignedBB(
                posX - halfThick, posY, posZ - halfWidth,
                posX + halfThick, posY + height, posZ + halfWidth
            ));
        }
    }

    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;

        int closeTicks = getClosingTicks();
        if (closeTicks > 0) {
            if (this.world.isRemote) {
                RickPortalMod.proxy.spawnPortalFx(4, this.posX, this.posY + 1.0D, this.posZ, 0, 0, 0, getPortalFacing().getHorizontalIndex());
            } else {
                if (closeTicks >= MAX_CLOSE_TICKS) {
                    this.setDead();
                    return;
                }
                setClosingTicks(closeTicks + 1);
            }
            this.recalculatePortalBoundingBox();
            return;
        }

        int openTicks = getOpeningTicks();
        if (openTicks < MAX_OPEN_TICKS) {
            if (!this.world.isRemote) {
                setOpeningTicks(openTicks + 1);
            }
        }

        this.recalculatePortalBoundingBox();

        if (this.world.isRemote) {
            RickPortalMod.proxy.spawnPortalFx(5, this.posX, this.posY, this.posZ, isLinked() ? 1.0D : 0.0D, 0, 0, getPortalFacing().getHorizontalIndex());
        } else {
            // Серверная обработка столкновений и телепортации игроков и мобов с обеих сторон
            if (this.isLinked() && openTicks >= 3) {
                AxisAlignedBB detectionBox = this.getEntityBoundingBox().grow(0.06D, 0.02D, 0.06D);
                List<Entity> collidingEntities = this.world.getEntitiesWithinAABBExcludingEntity(this, detectionBox);
                for (Entity entity : collidingEntities) {
                    if (canEntityTeleport(entity)) {
                        PortalTeleporter.tryTeleportEntity(entity, this);
                    }
                }
            }
            PortalTeleporter.tickCooldowns(this.world);
        }
    }

    private boolean canEntityTeleport(Entity entity) {
        if (entity == null || entity.isDead || entity instanceof EntityPortal) {
            return false;
        }
        if (entity.isRiding() || entity.isBeingRidden()) {
            return false;
        }
        return entity.isNonBoss();
    }

    public void startClosingAnimation() {
        if (getClosingTicks() == 0) {
            setLinked(false);
            setClosingTicks(1);
            recalculatePortalBoundingBox();
        }
    }

    public boolean isClosing() {
        return getClosingTicks() > 0;
    }

    @Nullable
    public UUID getOwnerUuid() {
        return this.dataManager.get(OWNER_UUID).orNull();
    }

    public void setOwnerUuid(@Nullable UUID uuid) {
        this.dataManager.set(OWNER_UUID, Optional.fromNullable(uuid));
    }

    public boolean isPrimary() {
        return this.dataManager.get(IS_PRIMARY);
    }

    public void setPrimary(boolean primary) {
        this.dataManager.set(IS_PRIMARY, primary);
    }

    public EnumFacing getPortalFacing() {
        int idx = this.dataManager.get(FACING_INDEX);
        return EnumFacing.byHorizontalIndex(Math.abs(idx) % 4);
    }

    public void setPortalFacing(EnumFacing facing) {
        if (facing == null || !facing.getAxis().isHorizontal()) {
            facing = EnumFacing.NORTH;
        }
        this.dataManager.set(FACING_INDEX, facing.getHorizontalIndex());
        this.rotationYaw = facing.getHorizontalAngle();
        this.recalculatePortalBoundingBox();
    }

    public boolean isLinked() {
        return this.dataManager.get(LINKED);
    }

    public void setLinked(boolean linked) {
        this.dataManager.set(LINKED, linked);
    }

    public void linkToDestination(int dimension, double x, double y, double z, EnumFacing facing) {
        this.dataManager.set(TARGET_DIM, dimension);
        this.dataManager.set(TARGET_X, (float) x);
        this.dataManager.set(TARGET_Y, (float) y);
        this.dataManager.set(TARGET_Z, (float) z);
        this.dataManager.set(TARGET_FACING, facing.getHorizontalIndex());
        this.dataManager.set(LINKED, Boolean.TRUE);
    }

    public int getTargetDimension() {
        return this.dataManager.get(TARGET_DIM);
    }

    public double getTargetX() {
        return this.dataManager.get(TARGET_X);
    }

    public double getTargetY() {
        return this.dataManager.get(TARGET_Y);
    }

    public double getTargetZ() {
        return this.dataManager.get(TARGET_Z);
    }

    public EnumFacing getTargetFacing() {
        return EnumFacing.byHorizontalIndex(Math.abs(this.dataManager.get(TARGET_FACING)) % 4);
    }

    public int getOpeningTicks() {
        return this.dataManager.get(OPENING_TICKS);
    }

    public void setOpeningTicks(int ticks) {
        this.dataManager.set(OPENING_TICKS, ticks);
    }

    public int getClosingTicks() {
        return this.dataManager.get(CLOSING_TICKS);
    }

    public void setClosingTicks(int ticks) {
        this.dataManager.set(CLOSING_TICKS, ticks);
    }

    public BlockPos getAnchorPos() {
        return anchorPos;
    }

    public void setAnchorPos(BlockPos pos) {
        this.anchorPos = pos;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean canBePushed() {
        return false;
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        return false;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public boolean isInRangeToRenderDist(double distance) {
        return distance < 16384.0D;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public int getBrightnessForRender() {
        return 15728880; // Полная яркость (240, 240) — светящийся портал
    }

    @Override
    public float getBrightness() {
        return 1.0F;
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound compound) {
        if (compound.hasUniqueId("OwnerUUID")) {
            setOwnerUuid(compound.getUniqueId("OwnerUUID"));
        }
        setPrimary(compound.getBoolean("IsPrimary"));
        setPortalFacing(EnumFacing.byHorizontalIndex(compound.getInteger("FacingIndex")));
        setLinked(compound.getBoolean("Linked"));
        this.dataManager.set(TARGET_DIM, compound.getInteger("TargetDim"));
        this.dataManager.set(TARGET_X, compound.getFloat("TargetX"));
        this.dataManager.set(TARGET_Y, compound.getFloat("TargetY"));
        this.dataManager.set(TARGET_Z, compound.getFloat("TargetZ"));
        this.dataManager.set(TARGET_FACING, compound.getInteger("TargetFacing"));
        setOpeningTicks(compound.getInteger("OpeningTicks"));
        setClosingTicks(compound.getInteger("ClosingTicks"));
        this.anchorPos = new BlockPos(
            compound.getInteger("AnchorX"),
            compound.getInteger("AnchorY"),
            compound.getInteger("AnchorZ")
        );
        this.recalculatePortalBoundingBox();
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound compound) {
        UUID owner = getOwnerUuid();
        if (owner != null) {
            compound.setUniqueId("OwnerUUID", owner);
        }
        compound.setBoolean("IsPrimary", isPrimary());
        compound.setInteger("FacingIndex", getPortalFacing().getHorizontalIndex());
        compound.setBoolean("Linked", isLinked());
        compound.setInteger("TargetDim", getTargetDimension());
        compound.setFloat("TargetX", (float) getTargetX());
        compound.setFloat("TargetY", (float) getTargetY());
        compound.setFloat("TargetZ", (float) getTargetZ());
        compound.setInteger("TargetFacing", getTargetFacing().getHorizontalIndex());
        compound.setInteger("OpeningTicks", getOpeningTicks());
        compound.setInteger("ClosingTicks", getClosingTicks());
        compound.setInteger("AnchorX", anchorPos.getX());
        compound.setInteger("AnchorY", anchorPos.getY());
        compound.setInteger("AnchorZ", anchorPos.getZ());
    }
}

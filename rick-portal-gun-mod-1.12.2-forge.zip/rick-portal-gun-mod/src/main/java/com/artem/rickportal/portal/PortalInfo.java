package com.artem.rickportal.portal;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

import javax.annotation.Nullable;
import java.util.UUID;

public class PortalInfo {

    private UUID entityUuid;
    private int dimension;
    private double posX;
    private double posY;
    private double posZ;
    private BlockPos anchorPos;
    private EnumFacing facing;

    public PortalInfo() {
        this.facing = EnumFacing.NORTH;
        this.anchorPos = BlockPos.ORIGIN;
    }

    public PortalInfo(@Nullable UUID entityUuid, int dimension, double posX, double posY, double posZ, BlockPos anchorPos, EnumFacing facing) {
        this.entityUuid = entityUuid;
        this.dimension = dimension;
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
        this.anchorPos = anchorPos != null ? anchorPos : new BlockPos(posX, posY, posZ);
        this.facing = (facing != null && facing.getAxis().isHorizontal()) ? facing : EnumFacing.NORTH;
    }

    @Nullable
    public UUID getEntityUuid() {
        return entityUuid;
    }

    public void setEntityUuid(@Nullable UUID entityUuid) {
        this.entityUuid = entityUuid;
    }

    public int getDimension() {
        return dimension;
    }

    public double getPosX() {
        return posX;
    }

    public double getPosY() {
        return posY;
    }

    public double getPosZ() {
        return posZ;
    }

    public BlockPos getAnchorPos() {
        return anchorPos;
    }

    public EnumFacing getFacing() {
        return facing;
    }

    public NBTTagCompound writeToNBT() {
        NBTTagCompound tag = new NBTTagCompound();
        if (entityUuid != null) {
            tag.setUniqueId("EntityUUID", entityUuid);
        }
        tag.setInteger("Dimension", dimension);
        tag.setDouble("PosX", posX);
        tag.setDouble("PosY", posY);
        tag.setDouble("PosZ", posZ);
        tag.setInteger("AnchorX", anchorPos.getX());
        tag.setInteger("AnchorY", anchorPos.getY());
        tag.setInteger("AnchorZ", anchorPos.getZ());
        tag.setInteger("Facing", facing.getHorizontalIndex());
        return tag;
    }

    public static PortalInfo readFromNBT(NBTTagCompound tag) {
        UUID uuid = tag.hasUniqueId("EntityUUID") ? tag.getUniqueId("EntityUUID") : null;
        int dim = tag.getInteger("Dimension");
        double x = tag.getDouble("PosX");
        double y = tag.getDouble("PosY");
        double z = tag.getDouble("PosZ");
        BlockPos anchor = new BlockPos(tag.getInteger("AnchorX"), tag.getInteger("AnchorY"), tag.getInteger("AnchorZ"));
        EnumFacing facing = EnumFacing.byHorizontalIndex(Math.abs(tag.getInteger("Facing")) % 4);
        return new PortalInfo(uuid, dim, x, y, z, anchor, facing);
    }
}

package com.artem.rickportal.portal;

import net.minecraft.nbt.NBTTagCompound;

import javax.annotation.Nullable;
import java.util.UUID;

public class PortalPair {

    private final UUID ownerUuid;
    private PortalInfo primary;
    private PortalInfo secondary;

    public PortalPair(UUID ownerUuid) {
        this.ownerUuid = ownerUuid;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    @Nullable
    public PortalInfo getPrimary() {
        return primary;
    }

    public void setPrimary(@Nullable PortalInfo primary) {
        this.primary = primary;
    }

    @Nullable
    public PortalInfo getSecondary() {
        return secondary;
    }

    public void setSecondary(@Nullable PortalInfo secondary) {
        this.secondary = secondary;
    }

    public boolean hasPrimary() {
        return primary != null;
    }

    public boolean hasSecondary() {
        return secondary != null;
    }

    public boolean isCompletePair() {
        return primary != null && secondary != null;
    }

    public NBTTagCompound writeToNBT() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setUniqueId("OwnerUUID", ownerUuid);
        if (primary != null) {
            tag.setTag("Primary", primary.writeToNBT());
        }
        if (secondary != null) {
            tag.setTag("Secondary", secondary.writeToNBT());
        }
        return tag;
    }

    public static PortalPair readFromNBT(NBTTagCompound tag) {
        UUID owner = tag.getUniqueId("OwnerUUID");
        PortalPair pair = new PortalPair(owner);
        if (tag.hasKey("Primary")) {
            pair.setPrimary(PortalInfo.readFromNBT(tag.getCompoundTag("Primary")));
        }
        if (tag.hasKey("Secondary")) {
            pair.setSecondary(PortalInfo.readFromNBT(tag.getCompoundTag("Secondary")));
        }
        return pair;
    }
}

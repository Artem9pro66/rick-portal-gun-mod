package com.artem.rickportal.network;

import com.artem.rickportal.portal.PortalManager;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketCreateCoordPortal implements IMessage {

    private int x;
    private int y;
    private int z;
    private int dimension;

    public PacketCreateCoordPortal() {
    }

    public PacketCreateCoordPortal(int x, int y, int z, int dimension) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.dimension = dimension;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        this.x = buf.readInt();
        this.y = buf.readInt();
        this.z = buf.readInt();
        this.dimension = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(this.x);
        buf.writeInt(this.y);
        buf.writeInt(this.z);
        buf.writeInt(this.dimension);
    }

    public static class Handler implements IMessageHandler<PacketCreateCoordPortal, IMessage> {
        @Override
        public IMessage onMessage(PacketCreateCoordPortal message, MessageContext ctx) {
            EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(() ->
                PortalManager.createSecondPortalByCoordinates(player, message.x, message.y, message.z, message.dimension)
            );
            return null;
        }
    }
}

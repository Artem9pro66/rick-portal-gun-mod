package com.artem.rickportal.proxy;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class CommonProxy {

    public void preInit(FMLPreInitializationEvent event) {
    }

    public void init(FMLInitializationEvent event) {
    }

    public void postInit(FMLPostInitializationEvent event) {
    }

    public void registerItemRenderer(Item item, int meta, String id) {
    }

    public void scheduleClientTask(Runnable task) {
    }

    public void handlePortalStatus(boolean success, String messageKey, Object... args) {
    }

    public void spawnPortalFx(int fxType, double x, double y, double z, double tx, double ty, double tz, int facingIndex) {
    }
}

package com.artem.rickportal.network;

import com.artem.rickportal.RickPortalMod;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketPortalFx implements IMessage {

    private int fxType;
    private double x;
    private double y;
    private double z;
    private double tx;
    private double ty;
    private double tz;
    private int facingIndex;

    public PacketPortalFx() {
    }

    public PacketPortalFx(int fxType, double x, double y, double z, double tx, double ty, double tz, int facingIndex) {
        this.fxType = fxType;
        this.x = x;
        this.y = y;
        this.z = z;
        this.tx = tx;
        this.ty = ty;
        this.tz = tz;
        this.facingIndex = facingIndex;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        this.fxType = buf.readByte();
        this.x = buf.readDouble();
        this.y = buf.readDouble();
        this.z = buf.readDouble();
        this.tx = buf.readDouble();
        this.ty = buf.readDouble();
        this.tz = buf.readDouble();
        this.facingIndex = buf.readByte();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeByte(this.fxType);
        buf.writeDouble(this.x);
        buf.writeDouble(this.y);
        buf.writeDouble(this.z);
        buf.writeDouble(this.tx);
        buf.writeDouble(this.ty);
        buf.writeDouble(this.tz);
        buf.writeByte(this.facingIndex);
    }

    public static class Handler implements IMessageHandler<PacketPortalFx, IMessage> {
        @Override
        public IMessage onMessage(PacketPortalFx message, MessageContext ctx) {
            RickPortalMod.proxy.scheduleClientTask(() ->
                RickPortalMod.proxy.spawnPortalFx(
                    message.fxType,
                    message.x, message.y, message.z,
                    message.tx, message.ty, message.tz,
                    message.facingIndex
                )
            );
            return null;
        }
    }
}

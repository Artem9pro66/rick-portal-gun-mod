package com.artem.rickportal.item;

import com.artem.rickportal.RickPortalMod;
import com.artem.rickportal.init.ModSounds;
import com.artem.rickportal.network.NetworkHandler;
import com.artem.rickportal.network.PacketPortalFx;
import com.artem.rickportal.network.PacketPortalStatus;
import com.artem.rickportal.portal.PortalManager;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;

public class ItemPortalGun extends Item {

    public static final double MAX_RANGE = 128.0D;

    public ItemPortalGun(String name) {
        this.setRegistryName(RickPortalMod.MODID, name);
        this.setTranslationKey(RickPortalMod.MODID + "." + name);
        this.setCreativeTab(RickPortalMod.CREATIVE_TAB);
        this.setMaxStackSize(1);
        // Бесконечная энергия: никаких повреждений, батареек, топлива или кулдаунов
        this.setMaxDamage(0);
        this.setNoRepair();
    }

    @Override
    public boolean isDamageable() {
        return false;
    }

    @Override
    public boolean showDurabilityBar(ItemStack stack) {
        return false;
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
        ItemStack stack = playerIn.getHeldItem(handIn);

        // Запрещаем кулдауны — игрок может стрелять без ограничений
        if (!worldIn.isRemote && playerIn instanceof EntityPlayerMP) {
            EntityPlayerMP playerMP = (EntityPlayerMP) playerIn;

            Vec3d eyePos = playerMP.getPositionEyes(1.0F);
            Vec3d lookVec = playerMP.getLook(1.0F);
            Vec3d reachVec = eyePos.add(lookVec.x * MAX_RANGE, lookVec.y * MAX_RANGE, lookVec.z * MAX_RANGE);

            RayTraceResult hit = worldIn.rayTraceBlocks(eyePos, reachVec, false, true, false);

            worldIn.playSound(
                null,
                playerMP.posX, playerMP.posY, playerMP.posZ,
                ModSounds.PORTAL_SHOOT,
                SoundCategory.PLAYERS,
                0.9F,
                1.0F + (worldIn.rand.nextFloat() - 0.5F) * 0.1F
            );

            Vec3d muzzlePos = eyePos.add(lookVec.scale(0.5D)).subtract(0.0D, 0.15D, 0.0D);

            if (hit == null || hit.typeOfHit != RayTraceResult.Type.BLOCK) {
                NetworkHandler.sendToAllAround(
                    new PacketPortalFx(0, muzzlePos.x, muzzlePos.y, muzzlePos.z, reachVec.x, reachVec.y, reachVec.z, 0),
                    worldIn.provider.getDimension(),
                    playerMP.posX, playerMP.posY, playerMP.posZ,
                    64.0D
                );
                return new ActionResult<>(EnumActionResult.SUCCESS, stack);
            }

            NetworkHandler.sendToAllAround(
                new PacketPortalFx(0, muzzlePos.x, muzzlePos.y, muzzlePos.z, hit.hitVec.x, hit.hitVec.y, hit.hitVec.z, hit.sideHit.getHorizontalIndex()),
                worldIn.provider.getDimension(),
                playerMP.posX, playerMP.posY, playerMP.posZ,
                64.0D
            );

            // Строгое требование: запрещено создавать порталы на полу (UP) или потолке (DOWN)
            if (hit.sideHit == EnumFacing.UP || hit.sideHit == EnumFacing.DOWN) {
                NetworkHandler.INSTANCE.sendTo(
                    new PacketPortalStatus(false, "msg.rickportal.err.vertical_only"),
                    playerMP
                );
                return new ActionResult<>(EnumActionResult.SUCCESS, stack);
            }

            PortalManager.handleRightClickShot(worldIn, playerMP, hit.getBlockPos(), hit.sideHit, hit.hitVec);
        }

        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
        tooltip.add(TextFormatting.GREEN + "Бесконечный межпространственный заряд");
        tooltip.add(TextFormatting.GRAY + "ПКМ по вертикальной стене: создать портал (#1 -> #2)");
        tooltip.add(TextFormatting.GRAY + "Клавиша [P]: создать портал #2 по координатам");
        tooltip.add(TextFormatting.GRAY + "Клавиша [K]: закрыть порталы Рика");
    }
}

package com.artem.rickportal.portal;

import com.artem.rickportal.entity.EntityPortal;
import com.artem.rickportal.init.ModSounds;
import com.artem.rickportal.network.NetworkHandler;
import com.artem.rickportal.network.PacketPortalFx;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Teleporter;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.util.ITeleporter;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PortalTeleporter extends Teleporter implements ITeleporter {

    private static final String NBT_COOLDOWN_KEY = "RickPortalCooldown";
    private static final int TELEPORT_COOLDOWN_TICKS = 28;
    private static final Map<UUID, Long> LAST_TELEPORT_TIME = new ConcurrentHashMap<>();

    private final double targetX;
    private final double targetY;
    private final double targetZ;
    private final float targetYaw;

    public PortalTeleporter(WorldServer worldIn, double targetX, double targetY, double targetZ, float targetYaw) {
        super(worldIn);
        this.targetX = targetX;
        this.targetY = targetY;
        this.targetZ = targetZ;
        this.targetYaw = targetYaw;
    }

    @Override
    public void placeEntity(World world, Entity entity, float yaw) {
        entity.setLocationAndAngles(targetX, targetY, targetZ, targetYaw, entity.rotationPitch);
        entity.motionX *= 0.5D;
        entity.motionY = Math.max(entity.motionY, 0.0D);
        entity.motionZ *= 0.5D;
        entity.fallDistance = 0.0F;
    }

    @Override
    public void placeInPortal(Entity entityIn, float rotationYaw) {
        placeEntity(this.world, entityIn, rotationYaw);
    }

    @Override
    public boolean placeInExistingPortal(Entity entityIn, float rotationYaw) {
        placeEntity(this.world, entityIn, rotationYaw);
        return true;
    }

    @Override
    public boolean makePortal(Entity entityIn) {
        return true;
    }

    @Override
    public void removeStalePortalLocations(long worldTime) {
        // Не создаём обсидиановые рамки Нижнего мира
    }

    public static void tickCooldowns(World world) {
        if (world.getTotalWorldTime() % 40L == 0L) {
            long now = System.currentTimeMillis();
            Iterator<Map.Entry<UUID, Long>> it = LAST_TELEPORT_TIME.entrySet().iterator();
            while (it.hasNext()) {
                if (now - it.next().getValue() > 5000L) {
                    it.remove();
                }
            }
        }
    }

    public static void tryTeleportEntity(Entity entity, EntityPortal sourcePortal) {
        if (entity.world.isRemote || !sourcePortal.isLinked() || sourcePortal.isClosing()) {
            return;
        }

        UUID entityId = entity.getUniqueID();
        long nowMs = System.currentTimeMillis();
        Long lastMs = LAST_TELEPORT_TIME.get(entityId);
        if (lastMs != null && (nowMs - lastMs) < 1350L) {
            return;
        }

        int nbtCooldown = entity.getEntityData().getInteger(NBT_COOLDOWN_KEY);
        long worldTick = entity.world.getTotalWorldTime();
        if (nbtCooldown > 0 && worldTick < nbtCooldown) {
            return;
        }

        MinecraftServer server = entity.getServer();
        if (server == null) {
            return;
        }

        int targetDim = sourcePortal.getTargetDimension();
        if (!DimensionManager.isDimensionRegistered(targetDim)) {
            return;
        }

        WorldServer destWorld = server.getWorld(targetDim);
        if (destWorld == null) {
            DimensionManager.initDimension(targetDim);
            destWorld = server.getWorld(targetDim);
        }
        if (destWorld == null) {
            return;
        }

        UUID ownerUuid = sourcePortal.getOwnerUuid();
        if (ownerUuid != null) {
            PortalSavedData savedData = PortalSavedData.get(entity.world);
            PortalPair pair = savedData.getPair(ownerUuid);
            if (pair == null || !pair.isCompletePair()) {
                sourcePortal.setLinked(false);
                return;
            }
            PortalInfo targetInfo = sourcePortal.isPrimary() ? pair.getSecondary() : pair.getPrimary();
            if (targetInfo != null) {
                PortalManager.findOrRestorePortalEntity(server, ownerUuid, !sourcePortal.isPrimary(), targetInfo);
            }
        }

        EnumFacing outFacing = sourcePortal.getTargetFacing();
        // Помещаем сущность перед выходным порталом со смещением по нормали
        double destX = sourcePortal.getTargetX() + outFacing.getXOffset() * 0.68D;
        double destY = sourcePortal.getTargetY() + 0.05D;
        double destZ = sourcePortal.getTargetZ() + outFacing.getZOffset() * 0.68D;
        float destYaw = outFacing.getHorizontalAngle();

        // Подгружаем чанк назначения перед перемещением
        destWorld.getChunkProvider().provideChunk(MathHelper.floor(destX) >> 4, MathHelper.floor(destZ) >> 4);

        // Устанавливаем защиту от бесконечной телепортации
        LAST_TELEPORT_TIME.put(entityId, nowMs);
        entity.getEntityData().setInteger(NBT_COOLDOWN_KEY, (int) (destWorld.getTotalWorldTime() + TELEPORT_COOLDOWN_TICKS));

        // Эффект и звук в точке входа
        entity.world.playSound(
            null,
            sourcePortal.posX, sourcePortal.posY + 1.0D, sourcePortal.posZ,
            ModSounds.PORTAL_TRAVEL,
            SoundCategory.PLAYERS,
            0.95F,
            1.0F
        );
        NetworkHandler.sendToAllAround(
            new PacketPortalFx(3, sourcePortal.posX, sourcePortal.posY + 1.0D, sourcePortal.posZ, 0, 0, 0, 0),
            entity.world.provider.getDimension(),
            sourcePortal.posX, sourcePortal.posY + 1.0D, sourcePortal.posZ,
            64.0D
        );

        int currentDim = entity.world.provider.getDimension();
        entity.fallDistance = 0.0F;

        if (currentDim == targetDim) {
            if (entity instanceof EntityPlayerMP) {
                EntityPlayerMP playerMP = (EntityPlayerMP) entity;
                playerMP.connection.setPlayerLocation(destX, destY, destZ, destYaw, playerMP.rotationPitch);
            } else {
                entity.setLocationAndAngles(destX, destY, destZ, destYaw, entity.rotationPitch);
            }
            entity.motionX = outFacing.getXOffset() * 0.18D;
            entity.motionZ = outFacing.getZOffset() * 0.18D;
            entity.velocityChanged = true;
        } else {
            PortalTeleporter teleporter = new PortalTeleporter(destWorld, destX, destY, destZ, destYaw);
            if (entity instanceof EntityPlayerMP) {
                EntityPlayerMP playerMP = (EntityPlayerMP) entity;
                server.getPlayerList().transferPlayerToDimension(playerMP, targetDim, teleporter);
                playerMP.connection.setPlayerLocation(destX, destY, destZ, destYaw, playerMP.rotationPitch);
                playerMP.getEntityData().setInteger(NBT_COOLDOWN_KEY, (int) (destWorld.getTotalWorldTime() + TELEPORT_COOLDOWN_TICKS));
            } else {
                Entity transferred = entity.changeDimension(targetDim, teleporter);
                if (transferred != null) {
                    transferred.setLocationAndAngles(destX, destY, destZ, destYaw, transferred.rotationPitch);
                    transferred.getEntityData().setInteger(NBT_COOLDOWN_KEY, (int) (destWorld.getTotalWorldTime() + TELEPORT_COOLDOWN_TICKS));
                    LAST_TELEPORT_TIME.put(transferred.getUniqueID(), nowMs);
                }
            }
        }

        // Эффект и звук в точке выхода
        destWorld.playSound(
            null,
            destX, destY + 1.0D, destZ,
            ModSounds.PORTAL_TRAVEL,
            SoundCategory.PLAYERS,
            0.95F,
            1.05F
        );
        NetworkHandler.sendToAllAround(
            new PacketPortalFx(3, destX, destY + 1.0D, destZ, 0, 0, 0, 0),
            targetDim,
            destX, destY + 1.0D, destZ,
            64.0D
        );
    }
}

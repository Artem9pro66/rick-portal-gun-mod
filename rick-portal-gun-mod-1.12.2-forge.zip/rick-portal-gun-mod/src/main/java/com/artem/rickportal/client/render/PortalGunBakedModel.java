package com.artem.rickportal.client.render;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.block.model.ItemOverrideList;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nullable;
import javax.vecmath.Matrix4f;
import java.util.List;

/**
 * Обёртка IBakedModel для портальной пушки Рика:
 * 1) Использует отдельную откалиброванную модель инвентаря (portal_gun_inventory) для GUI-слота
 *    и детальную 3D-модель (portal_gun) для отображения в руке от 1-го и 3-го лица.
 * 2) Отключает диффузное затенение на светящейся зелёной колбе (shade: false в JSON).
 */
@SideOnly(Side.CLIENT)
public class PortalGunBakedModel implements IBakedModel {

    private final IBakedModel handModel;
    private final IBakedModel inventoryModel;

    public PortalGunBakedModel(IBakedModel handModel, IBakedModel inventoryModel) {
        this.handModel = handModel;
        this.inventoryModel = inventoryModel != null ? inventoryModel : handModel;
    }

    @Override
    public List<BakedQuad> getQuads(@Nullable IBlockState state, @Nullable EnumFacing side, long rand) {
        return this.handModel.getQuads(state, side, rand);
    }

    @Override
    public boolean isAmbientOcclusion() {
        return false;
    }

    @Override
    public boolean isGui3d() {
        return true;
    }

    @Override
    public boolean isBuiltInRenderer() {
        return false;
    }

    @Override
    public TextureAtlasSprite getParticleTexture() {
        return this.handModel.getParticleTexture();
    }

    @Override
    @SuppressWarnings("deprecation")
    public ItemCameraTransforms getItemCameraTransforms() {
        return this.handModel.getItemCameraTransforms();
    }

    @Override
    public ItemOverrideList getOverrides() {
        return this.handModel.getOverrides();
    }

    @Override
    public Pair<? extends IBakedModel, Matrix4f> handlePerspective(ItemCameraTransforms.TransformType cameraTransformType) {
        if (cameraTransformType == ItemCameraTransforms.TransformType.GUI) {
            return this.inventoryModel.handlePerspective(cameraTransformType);
        }
        return this.handModel.handlePerspective(cameraTransformType);
    }
}
